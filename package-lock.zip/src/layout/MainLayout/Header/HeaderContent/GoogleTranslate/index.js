import { useEffect } from 'react';

const GoogleTranslate = () => {
  useEffect(() => {
    // Avoid reloading script if already present
    if (!document.querySelector('#google-translate-script')) {
      const script = document.createElement('script');
      script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
      script.id = 'google-translate-script';
      script.async = true;
      document.body.appendChild(script);
    }

    // Define the global function required by Google Translate
    window.googleTranslateElementInit = () => {
      if (!window.google?.translate?.TranslateElement) return;

      new window.google.translate.TranslateElement(
        {
          pageLanguage: 'en',
          includedLanguages: 'en,hi,fr,de,es',
          layout: window.google.translate.TranslateElement.InlineLayout.SIMPLE,
        },
        'google_translate_element'
      );
    };

    // Try hiding Google Translate toolbar & logo every second
    const interval = setInterval(() => {
      const iframe = document.querySelector('iframe.goog-te-banner-frame');
      if (iframe) {
        iframe.style.display = 'none';
        document.body.style.top = '0px';
      }

      const logo = document.querySelector('.goog-logo-link');
      if (logo) logo.style.display = 'none';

      const gadget = document.querySelector('.goog-te-gadget');
      if (gadget) gadget.style.color = 'transparent';
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  return <div id="google_translate_element" />;
};

export default GoogleTranslate;
